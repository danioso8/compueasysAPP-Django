-- Backup CompuEasys Database
-- Fecha: 2026-01-15 10:17:55
-- Base de datos: compueasys


-- auth.permission (232 registros)

-- auth.user (7 registros)

-- contenttypes.contenttype (58 registros)

-- sessions.session (3155 registros)

-- core.storevisit (4698 registros)

-- core.category (15 registros)

-- core.type (2 registros)

-- core.proveedor (10 registros)

-- core.productstore (71 registros)

-- core.productvariant (25 registros)

-- core.galeria (258 registros)

-- core.simpleuser (5 registros)

-- core.pedido (90 registros)

-- core.pedidodetalle (110 registros)

-- core.conversation (7 registros)

-- core.conversationmessage (14 registros)

-- core.stocknotification (4 registros)

-- core.notificationlog (5 registros)

-- core.whatsappconfig (1 registros)

-- contable.contableuser (2 registros)

-- contable.plan (3 registros)

-- contable.company (2 registros)

-- contable.userprofile (2 registros)

-- contable.companymembership (2 registros)

-- contable.auditlog (19 registros)

-- dashboard.wompiconfig (1 registros)

-- dashboard.storeconfig (1 registros)

-- dashboard.register_superuser (2 registros)
